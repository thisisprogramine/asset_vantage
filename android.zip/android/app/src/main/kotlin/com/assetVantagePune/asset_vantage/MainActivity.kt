package com.assetVantagePune.asset_vantage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
